rm part0000*
rm ptwuniform0.f0000*
rm uniform0.f0*
rm rpart00*
